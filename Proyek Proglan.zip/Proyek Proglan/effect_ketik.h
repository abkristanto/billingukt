#ifndef _effect_ketik_h
#define _effect_ketik_h
void ketik(char* a, int b);
#endif
